﻿namespace StrategyPattern.Interfaces
{

    public interface IPaymentStrategy
    {
        void Pay(int amount);
    }
}
