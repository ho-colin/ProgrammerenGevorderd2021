﻿namespace StrategyPattern.Models
{
    public class Game : Product
    {
        public Game(int price)
        {
            this.Price = price;
        }
    }
}