﻿namespace StrategyPattern.Models
{
    public class Poster : Product
    {
        public Poster(int price)
        {
            this.Price = price;
        }
    }
}