﻿namespace StrategyPattern.Models
{
    public class Sticker : Product
    {
        public Sticker(int price)
        {
            this.Price = price;
        }
    }
}